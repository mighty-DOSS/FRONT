export interface Cliente {
    id?: number;
    NomeCliente: string;
    CPF: string;
    email: string;
    data: string;
}
