export interface Categoria {
    id?: number;
    nome: string;
}
