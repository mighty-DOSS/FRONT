export interface Quarto {
    id?: number;
    NumeroQuarto: string;
    AndarQuarto: string;
    TipoQuarto: string;
    ValorDiaria: string;
    Disponivel: string;
}